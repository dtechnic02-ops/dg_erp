# DG ERP — IRD Open Items and Risk Register

| ID | Open item | Severity | Blocking impact | Current treatment |
|---|---|---|---|---|
| OI-001 | Written mapping for `zero_rated`, `out_of_scope`, and `total_sales` | Critical | Blocks CBMS payload implementation | See clarification register |
| OI-002 | CBMS durable state, payloads, HTTP transport, retry, and reconciliation not implemented | Critical | Blocks live CBMS integration | Intentionally not started |
| OI-003 | Live/test IRD taxpayer credentials not configured or exercised | High | Blocks connectivity verification | Obtain only through approved secure process |
| OI-004 | IRD Electronic Billing Software Listing not approved | Critical | Blocks any approval/listing claim | Submit only after technical/legal readiness |
| OI-005 | Customer Electronic Billing User Permission not configured | High | May block authorized deployment/use | Confirm IRD onboarding requirements |
| OI-006 | Independent security VAPT pending | High | Security assurance incomplete | Commission before production approval |
| OI-007 | Independent CA accounting/tax audit pending | High | External accounting/tax assurance incomplete | Obtain formal review |
| OI-008 | No dedicated general role-assignment audit logging | Medium | Governance evidence gap | Design separately; do not duplicate fiscal audit engine |
| OI-009 | `company.financial-years.show` route references a missing controller method | Medium | Dead read route; Auditor uses FY index | Separate scoped bug fix |
| OI-010 | Production deployment pending final approval | Critical | No production readiness claim | Require approved deployment checklist |
| OI-011 | Current CBMS fiscal-year/date formats and response envelope unresolved | Critical | Blocks safe serialization/success predicate | IRD-CLR-004 through 008 |
| OI-012 | Schedule 5 and Fiscal Sales Account require external IRD/CA format review | High | Prevents certification claim | Marked IMPLEMENTED / VERIFY WITH IRD |

Historical documents must not be auto-submitted, backfilled successful, or inferred from issuance age, print history, audit history, or current CBMS setting.

